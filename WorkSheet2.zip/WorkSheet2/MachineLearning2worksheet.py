#!/usr/bin/env python
# coding: utf-8

# # 1. Movie Recommendation systems are an example of:

# ii) Clustering

# # 2. Sentiment Analysis is an example of:

# i) Regression

# # 3. Can decision trees be used for performing clustering?
# 

# True

# # 4. Which of the following is the most appropriate strategy for data cleaning before performing clustering analysis, given less than desirable number of data points:

# 1. Capping and flouring of variables

# # 5. What is the minimum no. of variables/ features required to perform clustering?

# B. 1

# # 6. For two runs of K-Mean clustering is it expected to get same clustering results?

# B. No

# # 7.Is it possible that Assignment of observations to clusters does not change between successive iterations in K-Means?

# A. Yes

# # 8. Which of the following can act as possible termination conditions in K-Means?

# 1. For a fixed number of iterations.
# 2. Assignment   of   observations   to   clusters   does   not   change   betweeniterations. Except for cases with a bad local minimum.
# 3. Centroids do not change between successive iterations.
# 4. Terminate when RSS falls below a threshold
# 
# 
#  ans)all of the above

# # 9. Which of the following algorithms is most sensitive to outliers?

# A. K-means clustering algorithm

# # 10. How can Clustering (Unsupervised Learning) be used to improve the accuracy of Linear Regression model (Supervised Learning):

# i) Creating different models for different cluster groups.
# 
# ii) Creating an input feature for cluster ids as an ordinal variable.
# 
# iii) Creating an input feature for cluster centroids as a continuous variable.
# 
# iv) Creating an input feature for cluster size as a continuous variable.
# 
#  ans)all of the above

# # 11. What could be the possible reason(s) for producing two different dendrograms using agglomerative clustering algorithms for the same dataset?

# a) Proximity function used
# 
# b) of data points used
# 
# c) of variables used
# 
# ans) d) All of the above
# 

# #  Subjective answers type questions, Answers them in their own words briefly

# # 12. Is K sensitive to outliers?

# The K-means clustering algorithm is sensitive to outliers, because a mean is easily influenced by extreme values.
# 
# K-medoids clustering is a variant of K-means that is more robust to noises and outliers. 
# 
# Instead of using the mean point as the center of a cluster, K-medoids uses an actual point in the cluster to represent it. 
# 
# Medoid is the most centrally located object of the cluster, with minimum sum of distances to other points. 

# # 13. Why is K means better?

# Advantages of k-means
# 
# Relatively simple to implement.
# 
# Scales to large data sets.
# 
# Guarantees convergence.
# 
# Can warm-start the positions of centroids.
# 
# Easily adapts to new examples.
# 
# Generalizes to clusters of different shapes and sizes, such as elliptical clusters.
# 
# 

# # 14. Is K means a deterministic algorithm?

# The basic k-means clustering is based on a non-deterministic algorithm. 
# 
# This means that running the algorithm several times on the same data, could give different results.
# 
# 
# The non-deterministic nature of K-Means is due to its random selection of data points as initial centroids. ... The key idea of the algorithm is to select data points which belong to dense regions and which are adequately separated in feature space as the initial centroids.

# In[ ]:




