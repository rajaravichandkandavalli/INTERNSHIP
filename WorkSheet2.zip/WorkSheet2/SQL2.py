#!/usr/bin/env python
# coding: utf-8

# # 1.Which of the following constraint requires that there should not be duplicate entries?

# D) Unique

# # 2. Which of the following constraint allows null values in a column?

# C) Null

# # 3. Which of the following statements are true regarding Primary Key?

# B) There can be duplicate values in a primary key column

# # 4.Which of the following statements are true regrading Unique Key?

# A) There should not be any duplicate entries

# # 5.Which of the following is/ are example of referential constraint?

# B) Foreign Key

# # 6. How many foreign keys are there in the Supplier table?

# B)3

# # 7. The type of relationship between Supplier table and Product table is:

# A) one to many

# # 8. The type of relationship between Order table and Headquarter table is:

# D) many to many

# # 9.Which of the following is a foreign key in Delivery table?

# D) None of the them

# # 10.The number of foreign keys in order details is :

# D) 2

# # 11. The type of relationship between Order Detail table and Product table is:

# B) Many to one

# # 12.DDL statements perform operation on which of the following database objects?

# C) Table

# # 13. Which of the following statements is used to enter rows in table?

# A) Insert in to

# # 14. Which of the following is/are entity constraints in SQL?

# Unique and Primary key

# # 15. Which of the following statements is an example of sematic Constraint?

# D) Two or more donars can have same blood group

# In[ ]:




