#!/usr/bin/env python
# coding: utf-8

# # 1. What is a population parameter?
# 

# Standard Deviation and mean both are population parameter

# # 2. What will be median of the following set of scores(18,6,12,10,15)?

# 12

# # 3. What is standard deviation?

# D) All of the above

# # 4. The intervals should be Exhaustive and Mutually Exclusive in a grouped frequency distribution

# # 5.What is the goal of descriptive statistics?

# D) All of these

# # 6. A set of data organized in a participant by variables format is called

# B) Data set

# # 7. In multiple regression, 1 or more independent variables are used

# # 8.Which of the following is used when you want to visually examine the relationship between 2 quantitative variables

# B) Scatterplot

# # 9.Two or more groups means are compared by using 

# D)Analysis of variance

# # 10. ___ is a raw score which has been transformed in to standard deviation units

# A) Z-score

# # 11.____ is the value calculated when you want the arithmetic average?

# C)mean

# # 12. Find the mean of these set of number(4,6,7,9,2000000)?

#  D) 400005.2

# # 13. _____ is the central tendency that takes in to account the magnitude of scores?

# D) Mean

# # 14. ____ focuses on describing or explaining data where as____ involves going beyond immediate data and making inferences

# A) Descriptive and inferential

# # 15.What is the formula for range?

# D) H-L

# In[ ]:




